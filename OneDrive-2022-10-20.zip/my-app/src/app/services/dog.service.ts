import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { Dog } from '../models/dog';

@Injectable({
  providedIn: 'root'
})
export class DogService {

  constructor(private http: HttpClient) { }

  dogUrl = 'http://localhost:4000/dogs';

  isModalOpen$ = new BehaviorSubject(false);
  tempDog$ = new Subject<Dog>();

  getDogs() {
    return this.http.get<Dog[]>(this.dogUrl) as Observable<Dog[]>;
  }

  getDog(id: string) {
    return this.http.get<Dog>(`${this.dogUrl}/${id}`) as Observable<Dog>;
  }

  addDog(dog:Dog) {
    return this.http.post<Dog>(this.dogUrl, dog) as Observable<Dog>;
  }

  updateDog(dog:Dog) {
    return this.http.put<Dog>(`${this.dogUrl}/${dog.id}`, dog) as Observable<Dog>;
  }

  deleteDog(id:number) {
    return this.http.delete<Dog>(`${this.dogUrl}/${id}`) as Observable<Dog>;
  }
}

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Dog } from 'src/app/models/dog';
import { DogService } from 'src/app/services/dog.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {

  constructor(private dogService: DogService) { }

  dogSubscription: Subscription = new Subscription();
  dogs: Dog[] = [];
  dogsLength: number = 0;
  filteredDogs: Dog[] = [];
  isLoading: boolean = false;
  isModalOpen$ = this.dogService.isModalOpen$;

  startDisplayIndex: number = 0;
  numberOfDogs:number = 2;


  ngOnInit(): void {
   this.getDogs();
  }

  getDogs() {
    this.isLoading = true;
    this.dogSubscription = this.dogService.getDogs().subscribe((response) => {
      this.dogs = response;
      this.dogsLength = response.length;
      this.filterDogs();
      this.isLoading = false;
    });
  }

  filterDogs()  {
    this.filteredDogs = this.dogs.filter((dogs, index) => index >= this.startDisplayIndex && index < this.startDisplayIndex + this.numberOfDogs);
  }

  setStartDisplayIndex(index: number) {
    this.startDisplayIndex = index;
    this.filterDogs();
  }

  openModal() {
    this.isModalOpen$.next(true);
    this.dogService.tempDog$.next(new Dog());
  }


  ngOnDestroy(): void {
    this.dogSubscription.unsubscribe();
  }

}

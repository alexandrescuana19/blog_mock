import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { forkJoin, Subscription } from 'rxjs';
import { delay } from 'rxjs/operators';

import { Dog } from 'src/app/models/dog';
import { DogService } from 'src/app/services/dog.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit, OnDestroy {

  constructor(private route: ActivatedRoute, 
              private dogService: DogService) { }

  id: string = '';
  isLoading = false;
  dataSubscription = new Subscription();
  dogs: Dog[] = [];
  dog: Dog = new Dog();
  prevDogId: number = 0;
  nextDogId: number = 0;

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
      this.getData();
    });
  }

  getData(){
    this.isLoading  = true;
    this.dataSubscription = forkJoin([this.dogService.getDogs(), this.dogService.getDog(this.id)]).pipe(delay(1000)).subscribe((respose) => {
     this.dogs = respose[0];
     this.dog = respose[1];

     const curretDogIndex = this.dogs.findIndex((item) => item.id === this.dog.id);
     console.log(curretDogIndex);

     this.prevDogId = this.dogs[curretDogIndex - 1]  ? this.dogs[curretDogIndex - 1].id : 0;
     this.nextDogId = this.dogs[curretDogIndex + 1]  ? this.dogs[curretDogIndex + 1].id : 0;

     this.isLoading = false;
    })
  }

  ngOnDestroy(): void {
    this.dataSubscription.unsubscribe();
  }

}



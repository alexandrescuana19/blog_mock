export class Dog {
    name: string = '';
    img: string = '';
    id: number = 0;
}
import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Dog } from 'src/app/models/dog';
import { DogService } from 'src/app/services/dog.service';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit, OnDestroy {

  @Output() getDogs = new EventEmitter<string>();

  constructor(private dogService: DogService) { }

  isModalOpen$ = this.dogService.isModalOpen$;
  tempDogSubscription = new Subscription();
  addSubscription = new Subscription();
  updateSubscription = new Subscription();

  form = new FormGroup({
    'name': new FormControl('', [Validators.required]),
    'img': new FormControl('', [Validators.required]),
    'id': new FormControl(0)
  });

  ngOnInit(): void {
    this.tempDogSubscription = this.dogService.tempDog$.subscribe((dog: Dog) => {
      this.form = new FormGroup({
        'name': new FormControl(dog.name, [Validators.required]),
        'img': new FormControl(dog.img, [Validators.required]),
        'id': new FormControl(dog.id)
      });
    })
  }

  initForm() {
  }

  closeModal() {
    this.isModalOpen$.next(false);
  }

  clearImg() {
    this.form.controls.img.setValue('');
  }

  saveDog() {
    if (this.form.status === 'VALID') {

      if (this.form.getRawValue().id === 0) {
        this.addSubscription = this.dogService.addDog(this.form.getRawValue()).subscribe((response) => {
          console.log(response);
          this.getDogs.emit('');
          this.isModalOpen$.next(false);
        });
      } else {
        this.updateSubscription =  this.dogService.updateDog(this.form.getRawValue()).subscribe((response) => {
          console.log(response);
          this.getDogs.emit('');
          this.isModalOpen$.next(false);
        });
      }

    }

  }

  ngOnDestroy() {
    this.tempDogSubscription.unsubscribe();
    this.addSubscription.unsubscribe();
    this.updateSubscription.unsubscribe();
  }

}


import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Subscription } from 'rxjs';
import { Dog } from 'src/app/models/dog';
import { DogService } from 'src/app/services/dog.service';

@Component({
  selector: 'app-dog',
  templateUrl: './dog.component.html',
  styleUrls: ['./dog.component.css']
})
export class DogComponent implements OnInit {
  
  @Input() dog:Dog = new Dog();
  
  @Output() getDogs = new EventEmitter<string>();

  @Input() disableButtons:boolean = false;

  deleteSubscription = new Subscription();

  constructor(private dogService: DogService) { }

  ngOnInit(): void {
  }

  deleteDog(id: number) {
    this.deleteSubscription = this.dogService.deleteDog(id).subscribe((dog) => {
      console.log('Deleted dog');
      this.getDogs.emit('');
    })
  }

  editDog(dog:Dog) {
    this.dogService.isModalOpen$.next(true);
    this.dogService.tempDog$.next(dog);
  }

  ngOnDestroy() {
    this.deleteSubscription.unsubscribe();
  }

}

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css'],
  host: {'class': 'someClass1'}
})
export class FooterComponent implements OnInit {

  @Input() numberOfDogs: number = 2;
  @Input() startDisplayIndex: number = 0;
  @Input() dogsLength: number = 0;

  @Output() newGotoEvent = new EventEmitter<number>();
  
  constructor() { }

  ngOnInit(): void {
  }

  gotoPrevDogs() {
    this.newGotoEvent.emit(this.startDisplayIndex - this.numberOfDogs);
  }

  gotoNextDogs() {
    this.newGotoEvent.emit(this.startDisplayIndex + this.numberOfDogs);
  }

}
